Invoke with:
	timer_entropd

It'll log to syslog how many bits were added (loglevel DEBUG).


--- folkert@vanheusden.com
